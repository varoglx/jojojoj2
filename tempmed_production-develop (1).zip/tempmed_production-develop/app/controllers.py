from flask import  Blueprint,render_template
# from flask_socketio import socketIO
from app import app #app es la carpeta "app"
#socketio
from werkzeug.security import generate_password_hash
from app.db import db, configure_db  # Importa la instancia de SQLAlchemy y la función configure_db desde db.py
from sqlalchemy import text  # Importa la función text de SQLAlchemy
from datetime import datetime

#importacion de modelos para poblado
from app.user.models import Usuarios
from app.centros_clinicos.models import CentrosClinicos
from app.sucursales.models import Sucursales
from app.roles.models import Roles
from app.medicos.models import Medicos
from app.pacientes.models import Pacientes
from app.examenes.models import Examenes
from app.asociaciones.models import asociacion_rol_centro_clinico,asociacion_rol_sucursal,asociacion_usuario_centro_clinico,asociacion_usuario_sucursal
#inicializacion blueprint
general = Blueprint('app',__name__)

@app.route('/test_bd')
def test_bd():
    
    # Crea un objeto text con la consulta 'SHOW DATABASES'
    query = text('SHOW DATABASES')

    # Ejecuta la consulta usando SQLAlchemy a través del objeto session
    result = db.session.execute(query)

    # Obtiene los resultados de la consulta
    databases = [row[0] for row in result]

    return "Lista de bases de datos: {}".format(databases)

@app.route('/inicio')   
def index():


    return render_template('index.html')


@app.route('/administracion')
def administracion():
    return render_template('administracion.html')

@app.route('/poblado')
def poblado():
    # 1. Insertando datos para CentrosClinicos

    ciudades = ['Santiago', 'Valparaíso', 'Concepción', 'La Serena', 'Puerto Montt']
    comunas = ['Las Condes', 'Viña del Mar', 'Talcahuano', 'Coquimbo', 'Osorno']

    centros_clinicos_objs = []
    for i in range(5):
        centro = CentrosClinicos(
            rut=f"76.123.45{i}-{i}",
            nombre=f"Centro Médico {ciudades[i]}",
            ciudad=ciudades[i],
            comuna=comunas[i],
            fono=f"56 2 1234 56{i}",
            correo_electronico=f"contacto_{i}@centromedico.cl",
            especialidad="General",
            fecha_fundacion="2010-05-20",
            descripcion=f"Centro Médico en {ciudades[i]}"
        )
        db.session.add(centro)
        centros_clinicos_objs.append(centro)

    db.session.commit()
        
    # Definiendo nombres y apellidos para su uso posterior
    nombres = ["Juan", "Pedro", "María", "Sofía", "Lucas"]
    apellidos = ["González", "Pérez", "Fernández", "Valdés", "Gutiérrez"]

    # 2. Insertando datos para Medicos

    especialidades = ['Cardiología', 'Neurología', 'Pediatria', 'Ortopedia', 'Ginecología']

    medicos_objs = []
    for i in range(5):
        medico = Medicos(
            pnombre=nombres[i],
            snombre=nombres[(i+2)%5],
            papellido=apellidos[i],
            sapellido=apellidos[(i+3)%5],
            rut=f"19.345.67{i}-{i}",
            especialidad=especialidades[i],
            subespecialidad="",
            fecha_nacimiento="1980-03-15",
            genero="Masculino",
            direccion=f"Calle {comunas[i]} {i} depto 20{i}",
            correo_electronico=f"medico_{i}@clinic.cl",
            estado_licencia="Activa",
            telefono=f"56 9 1234 56{i}",
            fecha_ingreso="2022-01-15",
            foto=f"url/foto_medico_{i}.jpg",
            educacion="Universidad de Chile",
            horario_atencion="Lunes a Viernes 09:00 - 18:00",
            id_centro_clinico=i+1,
            Calificacion=4.5
        )
        db.session.add(medico)
        medicos_objs.append(medico)

    db.session.commit()

        
    # 3. Insertando datos para Pacientes

    nombres_pacientes = ['Juan', 'Maria', 'Carlos', 'Sofía', 'Fernanda']
    apellidos_pacientes = ['Perez', 'Gonzalez', 'Lopez', 'Herrera', 'Valdes']

    pacientes_objs = []
    for i in range(5):
        paciente = Pacientes(
            rut=f"23.456.78{i}-{i}",
            nombre=nombres_pacientes[i],
            apellidos=apellidos_pacientes[i],
            prevision="Fonasa",
            fecha_nacimiento="1990-04-10",
            edad=33,
            genero="Femenino" if i%2 == 0 else "Masculino",
            direccion=f"Calle {comunas[i]} {i+5} depto 30{i}",
            ciudad=ciudades[i],
            telefono=f"56 9 5678 56{i}",
            email=f"paciente_{i}@mail.cl",
            seguro_medico="CruzBlanca",
            fecha_registro="2022-08-15",
            medico_asignado=medicos_objs[i].pnombre,
            ultima_visita="2023-01-10",
            notas="Paciente regular.",
            id_centro_clinico=i+1
        )
        db.session.add(paciente)
        pacientes_objs.append(paciente)

    db.session.commit()


    # 4. Insertando datos para Roles

    roles_nombres = ['Admin', 'Medico', 'Paciente', 'Recepcionista', 'Enfermero']
    roles_objs = []

    for rol in roles_nombres:
        role = Roles(nombre=rol)
        db.session.add(role)
        roles_objs.append(role)

    db.session.commit()
    
    # 5. Insertando datos para Usuarios

    usuarios_emails = ['admin@mail.cl', 'medico@mail.cl', 'paciente@mail.cl', 'recepcion@mail.cl', 'enfermero@mail.cl']

    usuarios_objs = []
    for i in range(5):
        usuario = Usuarios(
            email=usuarios_emails[i],
            username=nombres_pacientes[i],
            nombre=nombres_pacientes[i],
            apellido=apellidos_pacientes[i],
            centro_actual=i+1,
            password=generate_password_hash("password")  # esto debería ser una hash en una aplicación real
        )
        db.session.add(usuario)
        usuarios_objs.append(usuario)
    # 6. Insertando datos para Examenes

    tipos_de_examenes = ['Sangre', 'Orina', 'Radiografía', 'Resonancia Magnética', 'Ecografía']

    examenes_objs = []
    for i in range(5):
        examen = Examenes(
            medico_id=medicos_objs[i].id_medico,
            paciente_id=pacientes_objs[i].id,
            empresa_id=i+1,  # Suponiendo que ya has poblado empresas
            sucursal_id=i+1, 
            tipo_de_examen=tipos_de_examenes[i],
            resultados="Resultados de prueba",
            estado="Completado"
        )
        db.session.add(examen)
        examenes_objs.append(examen)

    db.session.commit()

    # Poblado de Sucursales

    sucursales_nombres = ['Sucursal A', 'Sucursal B', 'Sucursal C', 'Sucursal D', 'Sucursal E']
    correos_sucursales = ['sucursalA@clinic.cl', 'sucursalB@clinic.cl', 'sucursalC@clinic.cl', 'sucursalD@clinic.cl', 'sucursalE@clinic.cl']

    sucursales_objs = []
    for i in range(5):
        sucursal = Sucursales(
            nombre=sucursales_nombres[i],
            direccion=f"Calle {comunas[i]} {i+10} depto 40{i}",
            comuna=comunas[i],
            region="Región Metropolitana",
            telefono=f"+56 2 2345 67{i}",
            correo_electronico=correos_sucursales[i],
            fecha_creacion="2022-01-15",
            activa=True,
            id_centro_clinico=i+1
        )
        db.session.add(sucursal)
        sucursales_objs.append(sucursal)

    db.session.commit()


    # 8. Poblando las asociaciones

    # Asociación usuario-sucursal
    for i in range(5):
        asociacion_us = asociacion_usuario_sucursal.insert().values(usuario_id=usuarios_objs[i].id, sucursal_id=sucursales_objs[i].id)
        db.session.execute(asociacion_us)

    # Asociación usuario-centro_clinico
    for i in range(5):
        asociacion_uc = asociacion_usuario_centro_clinico.insert().values(usuario_id=usuarios_objs[i].id, centroclinico_id=i+1)
        db.session.execute(asociacion_uc)

    # Asociación rol-sucursal
    for i in range(5):
        asociacion_rs = asociacion_rol_sucursal.insert().values(usuario_id=usuarios_objs[i].id, rol_id=roles_objs[i].id, sucursal_id=sucursales_objs[i].id)
        db.session.execute(asociacion_rs)

    # Asociación rol-centro_clinico
    for i in range(5):
        asociacion_rc = asociacion_rol_centro_clinico.insert().values(usuario_id=usuarios_objs[i].id, rol_id=roles_objs[i].id, centro_clinico_id=i+1)
        db.session.execute(asociacion_rc)

    db.session.commit()
    stmt = asociacion_usuario_centro_clinico.insert().values(usuario_id=1, centroclinico_id=2)
    stmt2 = asociacion_usuario_centro_clinico.insert().values(usuario_id=1, centroclinico_id=3)
    stmt3 = asociacion_usuario_centro_clinico.insert().values(usuario_id=1, centroclinico_id=4)
    db.session.execute(stmt)
    db.session.execute(stmt2)
    db.session.execute(stmt3)
    db.session.commit()
    
    
    
    return render_template('poblado.html')
    
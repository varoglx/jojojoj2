from wtforms.validators import InputRequired,EqualTo,Email
from flask_wtf import FlaskForm
from wtforms import StringField,DateField,SelectField

from wtforms import StringField, SelectField, DateField
from wtforms.validators import InputRequired, Email

class RegisterPaciente(FlaskForm):
    rut = StringField('RUT (*)', validators=[InputRequired(message="El campo RUT es obligatorio")])
    nombre = StringField('Nombre (*)', validators=[InputRequired(message="El campo Nombre es obligatorio")])
    apellidos = StringField('Apellidos (*)', validators=[InputRequired(message="El campo Apellidos es obligatorio")])
    fecha_nacimiento = DateField('Fecha nacimiento (*)', validators=[InputRequired(message="El campo Fecha de Nacimiento es obligatorio")])
    prevision = StringField('Prevision (*)', validators=[InputRequired(message="El campo Previsión es obligatorio")])
    edad = StringField('Edad', validators=[InputRequired(message="El campo Edad es obligatorio")])
    genero = SelectField('Género', choices=[('O', 'Otro'), ('M', 'Masculino'), ('F', 'Femenino')])
    direccion = StringField('Direccion (*)', validators=[InputRequired(message="El campo Dirección es obligatorio")])
    ciudad = StringField('Ciudad (*)', validators=[InputRequired(message="El campo Ciudad es obligatorio")])
    telefono = StringField('Telefono')
    email = StringField('Correo electronico', validators=[Email(message="Introduce un correo electrónico válido")])
    seguro_medico = StringField('Seguro medico', validators=[InputRequired(message="El campo Seguro Médico es obligatorio")])
    #medico_asignado = StringField('Medico asignado')
    #ultima_visita = DateField('Ultima visita')


    notas = StringField('Nota')
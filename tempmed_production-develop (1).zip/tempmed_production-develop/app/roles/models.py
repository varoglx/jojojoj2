from app.asociaciones.models import asociacion_rol_centro_clinico,asociacion_rol_sucursal
from app.db import db
from sqlalchemy import Column, Date
from sqlalchemy.orm import relationship




class Roles(db.Model):
 

    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50))  # Ejemplo: 'Medico', 'Paciente', 'Admin', etc.

    # Relación con Usuarios

    usuarios_por_sucursal = relationship('Usuarios', secondary=asociacion_rol_sucursal, back_populates='roles_por_sucursal')
    usuarios_por_centro_clinico = relationship('Usuarios', secondary=asociacion_rol_centro_clinico, back_populates='roles_por_centro_clinico')
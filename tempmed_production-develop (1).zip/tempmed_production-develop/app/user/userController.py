from flask import Blueprint,render_template,url_for,redirect,flash,jsonify,request
from werkzeug.security import generate_password_hash,check_password_hash
from app.user.models import Usuarios,UsuariosCentro
from app.user.forms import RegisterForm,LoginForm
from app.centros_clinicos.models import CentrosClinicos
from app.db import db
from app import login_manager   
from flask_login import login_user,current_user,login_required,logout_user
from flask import session
from app import app

@login_manager.user_loader
def load_user(user_id):
    
    return Usuarios.query.get(user_id)

usuarioBP = Blueprint('user',__name__)


@usuarioBP.route('/registrar_usuario', methods=('GET', 'POST'))
def register():
    
    form = RegisterForm(meta={ 'csrf':False})

    if form.validate_on_submit():
        centro_clinico_id = request.form.get('centros_clinicos')

        if Usuarios.query.filter_by(username=form.username.data).first():#replicar para email
            flash("Usuario duplicado", "error")
            return redirect(url_for('user.register'))

        else:
            user = Usuarios()
            user.username = form.username.data
            user.password = generate_password_hash(form.password.data)
            user.nombre = form.nombre.data
            user.apellido = form.apellido.data    
            user.email = form.email.data
            user.centro_actual = centro_clinico_id

            db.session.add(user)
            db.session.commit()

            user_centro = UsuariosCentro()  # Crear una instancia de UsuariosCentro
            user_centro.id_usuario = user.id  # Asignar el ID del usuario
            user_centro.es_admin = 1
            user_centro.id_centro = centro_clinico_id
            db.session.add(user_centro)
            db.session.commit()

            login_user(user,remember=True)
            flash("Usuario registrado con exito!!!", "succes")
            return redirect(url_for('user.register'))

    if form.errors:
        print(form.errors)
    return render_template('user/register_user.html',form=form)

from app.asociaciones.models import asociacion_usuario_centro_clinico
@usuarioBP.route('/', methods=['GET', 'POST'])
def login():
    


    form = LoginForm()
    if form.validate_on_submit():#valida el formulario 
        user = Usuarios.query.filter_by(username=form.username.data).first()#consulta si esta el usuario
        
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user)
                
                registros_asociados = db.session.query(asociacion_usuario_centro_clinico).filter_by(usuario_id=user.id).all()

                # El número de centros clínicos asociados al usuario es simplemente la longitud de registros_asociados
                num_centros_clinicos = len(registros_asociados)

                if num_centros_clinicos == 1:
                    # Si solo tiene una clínica asociada, puedes asignarla directamente y redirigir a la página principal
                    session['centro_clinico_id'] = registros_asociados[0].centroclinico_id
                    print('este es el id de el centro medico iniciado sesion ',session['centro_clinico_id'])
                    return redirect(url_for('index'))

                elif num_centros_clinicos > 1:
                    # Si tiene más de una clínica asociada, redirige a la página para seleccionar clínica
                    return redirect(url_for('seleccionar_clinica'))

                else:
                    # Si no tiene ninguna clínica asociada, maneja este caso como mejor te parezca (p.ej., mostrar un mensaje de error)
                    flash('No tienes ninguna clínica asociada.', 'error')
                    return redirect(url_for('login'))   

        else:
            flash('Usuario o contraseña incorrectos.', 'error')
            return redirect(url_for('user.login'))  



    return render_template('user/login.html', form=form)

@usuarioBP.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('user.login'))


@usuarioBP.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    return render_template('user/dashboard.html')


@usuarioBP.route('/perfil')
def perfil():
    return render_template('user/dashboard.html')

@usuarioBP.route('/obtener_centros_clinicos_api',methods=['GET', 'POST'])
def obtener_centros_clinicos_api():
    centros = CentrosClinicos.query.all()
    centros_clinicos_serializable = []
    for c in centros:

       centros_dict = {
            'id': c.id,
            'rut': c.rut
        }
       centros_clinicos_serializable.append(centros_dict)
 
    return jsonify({'centros': centros_clinicos_serializable})




@app.route('/seleccionar_clinica', methods=['GET', 'POST'])
def seleccionar_clinica():
    if not current_user.is_authenticated:
        flash('Por favor inicia sesión para acceder a esta página.', 'error')
        return redirect(url_for('login'))
    
    clinicas_asociadas = current_user.centro_clinico
    
    if request.method == 'POST':
        centro_clinico_id = request.form.get('centro_clinico_id')
        if centro_clinico_id:
            session['centro_clinico_id'] = centro_clinico_id
            print('este es el id del centro medico ',session['centro_clinico_id'])
            return redirect(url_for('index'))

    return render_template('user/seleccionar_clinica.html', clinicas=clinicas_asociadas)

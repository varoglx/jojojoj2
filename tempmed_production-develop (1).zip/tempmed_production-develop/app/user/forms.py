from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField,SubmitField,SelectField,SelectMultipleField
from wtforms.validators import InputRequired,EqualTo,Length,Email
from app.centros_clinicos.models import CentrosClinicos

class RegisterForm(FlaskForm):
    username = StringField('Usuario (*)',validators=[ InputRequired() ])
    nombre = StringField('Nombre (*)',validators=[ InputRequired() ])
    apellido = StringField('Apellido (*)',validators=[ InputRequired() ])
    password = PasswordField('Contraseña (*)',validators=[ InputRequired(), EqualTo('confirm') ])
    confirm = PasswordField('Confirmar contraseña (*)',validators=[ InputRequired() ])
    email = StringField('Correo electronico',validators=[ InputRequired(), Email() ])

class LoginForm(FlaskForm):#formulario de login
    username = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[        
                            #CORREGUIR VALIDACIONES DEL LARGO 8 CARACTERES                  
                             InputRequired(), Length(min=5, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Login')

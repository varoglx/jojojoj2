from app.db import db
from sqlalchemy import Column, Date,Float

class Medicos(db.Model):
    # Identificador único para cada médico.
    id_medico = db.Column(db.Integer, primary_key=True)
    
    # Nombre del médico.
    pnombre = db.Column(db.String(100))
    snombre = db.Column(db.String(100))
    papellido =db.Column(db.String(100))
    sapellido =db.Column(db.String(100))
    
    # Rol Único Tributario del médico
    rut =db.Column(db.String(100))
    
    # Especialidad médica a la que pertenece el médico.
    especialidad = db.Column(db.String(100))
    
    # Subespecialidad del médico (si la tiene)
    subespecialidad = db.Column(db.String(100))
    
    # Fecha de nacimiento del médico.
    fecha_nacimiento = db.Column(Date)
    
    # Género del médico.
    genero = db.Column(db.String(100))
    
    # Dirección de residencia o trabajo del médico.
    direccion = db.Column(db.String(200))
    
    # Dirección de correo electrónico del médico.
    correo_electronico = db.Column(db.String(150))
    
    # Indica si el médico tiene una licencia activa, suspendida, etc.
    estado_licencia = db.Column(db.String(100))
    
    # Número telefónico de contacto.
    telefono = db.Column(db.String(15))
    
    # Fecha en que el médico comenzó a trabajar en el centro médico.
    fecha_ingreso = db.Column(Date)
    
    #Una imagen o foto del médico (opcional).
    foto = db.Column(db.String(150))
    
    #Institucion donde el medico obtuvo su educacion y formacion
    educacion = db.Column(db.String(150))
    
    # Horarios en los que el médico atiende a sus pacientes.
    horario_atencion=db.Column(db.String(200))
    
    # El centro médico o hospital donde el médico presta sus servicios.
    id_centro_clinico = db.Column(db.Integer, db.ForeignKey('centros_clinicos.id'), nullable=False)


    # Puntuación o valoración media recibida por el médico de parte de los pacientes.
    Calificacion = Column(Float)
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateTimeField, TextAreaField, SelectField,DateField,SubmitField
from wtforms.validators import DataRequired, Email, Length, InputRequired

class RegisterMedico(FlaskForm):
    pnombre = StringField('Primer Nombre (*)', validators=[InputRequired(message="El campo Primer Nombre es obligatorio"), Length(max=100)])
    snombre = StringField('Segundo Nombre', validators=[Length(max=100)])
    papellido = StringField('Primer Apellido (*)', validators=[InputRequired(message="El campo Primer Apellido es obligatorio"), Length(max=100)])
    sapellido = StringField('Segundo Apellido (*)', validators=[InputRequired(message="El campo Segundo Apellido es obligatorio"), Length(max=100)])
    rut = StringField('RUT (*)', validators=[InputRequired(message="El campo RUT es obligatorio"), Length(max=100)])
    especialidad = StringField('Especialidad (*)', validators=[InputRequired(message="El campo Especialidad es obligatorio"), Length(max=100)])
    subespecialidad = StringField('Subespecialidad', validators=[Length(max=100)])
    fecha_nacimiento = DateField('Fecha de Nacimiento (*)', validators=[InputRequired(message="El campo Fecha de Nacimiento es obligatorio")])
    genero = SelectField('Género (*)', 
                         choices=[('', 'Seleccione un género'), ('Masculino', 'Masculino'), ('Femenino', 'Femenino')],
                         validators=[InputRequired(message="El campo Género es obligatorio"), Length(max=100)])
    direccion = StringField('Dirección', validators=[Length(max=200)])
    correo_electronico = StringField('Correo Electrónico (*)', validators=[InputRequired(message="El campo Correo Electrónico es obligatorio"), Email(message="Ingrese un correo electrónico válido"), Length(max=150)])
    estado_licencia = SelectField('Estado de Licencia', 
                         choices=[('', 'Seleccione un género'), ('Vigente', 'Vigente'), ('Vencido', 'Vencido')],
                         validators=[InputRequired(message="El campo Género es obligatorio"), Length(max=100)])
    telefono = StringField('Teléfono', validators=[Length(max=15)])
    fecha_ingreso = DateField('Fecha de Ingreso')
    foto = StringField('Foto', validators=[Length(max=150)])
    educacion = StringField('Educación', validators=[Length(max=150)])
    horario_atencion = StringField('Horario de Atención', validators=[Length(max=200)])
    submit = SubmitField('Registrar Médico')

from app.db import db
from flask import Blueprint, render_template, jsonify, request
from app.examenes.models import Examenes
from app.examenes.forms import RegisterExamenes

examenesBP = Blueprint('examenes', __name__)

@examenesBP.route('/registrar_examenes', methods=('GET', 'POST'))
def registrarExamenes():
    form = RegisterExamenes()
    if form.validate_on_submit():
        print('valido')
        if Examenes.query.filter_by(examen_id=form.examen_id.data).first():
            print("este Examen ya existe")
        else:
            examenes = Examenes()
            examenes.examen_id = form.examen_id.data
            examenes.medico_id = form.medico_id.data
            examenes.paciente_id = form.paciente_id.data
            examenes.empresa_id = form.empresa_id.data
            examenes.sucursal_id = form.sucursal_id.data
            examenes.tipo_de_examen = form.tipo_de_examen.data
            examenes.resultados = form.resultados.data
            examenes.estado = form.estado.data
            db.session.add(examenes)
            db.session.commit()
            print('guardado')

        if form.errors:
            print(form.errors)
            return render_template('examenes/register_examenes.html', form=form)
    return render_template('examenes/register_examenes.html', form=form)



@examenesBP.route('/examenes/lista_examenes', methods=('GET', 'POST'))
def listar_examenes_view():
    return render_template('examenes/listar_examenes.html')

@examenesBP.route('/examenes_listar_api', methods=['GET'])
def examenes_listar_api():
    examenes = Examenes.query.all()
    examenes_serializable = []
    for examen in examenes:
        examen_dict = {
            'examen_id': examen.examen_id,
            'medico_id': examen.medico_id,
            'paciente_id': examen.paciente_id,
            'empresa_id': examen.empresa_id,
            'sucursal_id': examen.sucursal_id,
            'tipo_de_examen': examen.tipo_de_examen,
            'resultados': examen.resultados,
            'estado': examen.estado,
        }
        examenes_serializable.append(examen_dict)

    return jsonify({'examenes': examenes_serializable})

@examenesBP.route('/examenes/editar_examen/<id_examen>', methods=['GET','POST'])
def editar_examen(id_examen):
    form = RegisterExamenes()
    examen = Examenes.query.filter_by(examen_id=id_examen).first()
    if examen:
        if request.method == 'POST':
            examen.examen_id = request.form.get('examen_id')
            examen.medico_id = request.form.get('medico_id')
            examen.paciente_id = request.form.get('paciente_id')
            examen.empresa_id = request.form.get('empresa_id')
            examen.sucursal_id = request.form.get('sucursal_id')
            examen.tipo_de_examen = request.form.get('tipo_de_examen')
            examen.resultados = request.form.get('resultados')
            examen.estado = request.form.get('estado')
            db.session.commit()
    return render_template('examenes/editar_examenes.html', examenes=examen, form=form)

@examenesBP.route('/examenes/eliminar_examen', methods=['GET','POST'])
def eliminar_examen_api():
    id_examen = request.form.get('examen_id')
    examen = Examenes.query.filter_by(examen_id=id_examen).first()
    if examen:
        db.session.delete(examen)
        db.session.commit()
        return jsonify({"message": "Examen eliminado correctamente"})
    else:
        return jsonify({"message": "Examen no encontrado"})

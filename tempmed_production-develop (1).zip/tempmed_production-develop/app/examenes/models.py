from app.db import db
from sqlalchemy import Column

class Examenes(db.Model):


    examen_id = db.Column(db.Integer, primary_key=True)
    medico_id = db.Column(db.Integer)  # , db.ForeignKey('Medicos.MedicoID'))
    paciente_id = db.Column(db.Integer)  # , db.ForeignKey('Pacientes.PacienteID'))
    empresa_id = db.Column(db.Integer)  # , db.ForeignKey('Empresas.EmpresaID'))
    sucursal_id = db.Column(db.Integer)  # , db.ForeignKey('Sucursales.SucursalID'))
    tipo_de_examen = db.Column(db.String(255))
    resultados = db.Column(db.String(255))  # Puedes cambiar el tipo según tus necesidades
    estado = db.Column(db.String(255))
    # Puedes agregar más campos aquí según la información adicional que mencionaste
